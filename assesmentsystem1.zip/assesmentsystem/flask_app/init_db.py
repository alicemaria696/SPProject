from app import app, db
from app.models import User

with app.app_context():
    db.create_all()
    # Optional: Add sample users
    admin = User(reg_id='A2447145', name='Admin', password='2345678', role='A')
    teacher = User(reg_id='T1001', name='Teacher', password='teach123', role='T')
    student = User(reg_id='S1001', name='Student', password='stud123', role='S')
    
    db.session.add_all([admin, teacher, student])
    db.session.commit()

    print("✅ Database initialized and test users created.")
